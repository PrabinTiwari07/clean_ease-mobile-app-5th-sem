import 'package:get_it/get_it.dart';

final serviceLocator = GetIt.instance;
Future<void> initDependency() async {
  _initBloc();
}

void _initBloc() {}
