class HiveTableConstant {
  HiveTableConstant._();

  static const int userTableId = 0;
  static const String userBox = 'userBox';

  // static const int bookingTableId = 1;
  // static const String bookingBox = 'bookingBox';

  static const int serviceTableId = 2;
  static const String serviceBox = 'serviceBox';

  static const int profileTableId = 2;
  static const String profileBox = "profile_box";
}
